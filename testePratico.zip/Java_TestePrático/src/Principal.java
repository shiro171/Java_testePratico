import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class Principal {
    public static void main(String[] args) {
        List<Funcionario> funcionarios = new ArrayList<>();

        // Adicionando funcionários
        funcionarios.add(new Funcionario("Maria", LocalDate.of(2000, 10, 18), new BigDecimal("2009.44"), "Caixa"));
        funcionarios.add(new Funcionario("João", LocalDate.of(2001, 7, 12), new BigDecimal("2284.38"), "Operador"));
        funcionarios.add(new Funcionario("Caio", LocalDate.of(1990, 5, 2), new BigDecimal("9836.14"), "Coordenador"));
        funcionarios.add(new Funcionario("Miguel", LocalDate.of(1988, 10, 14), new BigDecimal("19119.88"), "Diretor"));
        funcionarios.add(new Funcionario("Alice", LocalDate.of(1995, 01,05 ), new BigDecimal("2234.68"), "Recepcionista"));
        funcionarios.add(new Funcionario("Heitor", LocalDate.of(1999, 11,19 ), new BigDecimal("1582.72"), "Operador"));
        funcionarios.add(new Funcionario("Arthur", LocalDate.of(1993,03 ,31 ), new BigDecimal("4071.84"), "Contador"));
        funcionarios.add(new Funcionario("Laura", LocalDate.of(1994, 07,8 ), new BigDecimal("3017.45"), "Gerente"));
        funcionarios.add(new Funcionario("Heloísa", LocalDate.of(2003, 05,24 ), new BigDecimal("1606.85"), "Eletricista"));
        funcionarios.add(new Funcionario("Helena", LocalDate.of(1996, 9,2 ), new BigDecimal("2799.93"), "Operador"));
        
        // Adicionar os demais funcionários conforme a tabela fornecida

        // Remover funcionário "João"
        funcionarios.removeIf(f -> f.getNome().equals("João"));

        // Imprimir todos os funcionários com todas suas informações
        imprimirFuncionarios(funcionarios );

        // Aumentar salário dos funcionários em 10%
        funcionarios.forEach(f -> f.setSalario(f.getSalario().multiply(BigDecimal.valueOf(1.1))));

        // Agrupar funcionários por função
        Map<String, List<Funcionario>> funcionariosPorFuncao = funcionarios.stream()
                .collect(Collectors.groupingBy(Funcionario::getFuncao));

        // Imprimir funcionários agrupados por função
        funcionariosPorFuncao.forEach((funcao, lista) -> {
            System.out.println("\n" +"Função: " + funcao);
            lista.forEach(System.out::println);
        });

        // Imprimir funcionários que fazem aniversário nos meses 10 e 12
        System.out.println("\n"+"O seguintes funcionários fazem aniverário nos meses 10 e 12");
        funcionarios.stream()
                .filter(f -> f.getDataNascimento().getMonthValue() == 10 || f.getDataNascimento().getMonthValue() == 12)
                .forEach(f -> {
                    System.out.println("Nome: " + f.getNome());
                    System.out.println("Data de Nascimento: " + f.getDataNascimento().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    System.out.println(); // Linha em branco para separar os funcionários
                });
        // Imprimir funcionário com maior idade
        Funcionario funcionarioMaisVelho = funcionarios.stream()
                .min(Comparator.comparing(Funcionario::getDataNascimento))
                .orElse(null);
        System.out.println("\n"+"Funcionário com maior idade: " + funcionarioMaisVelho +"\n");

        // Imprimir lista de funcionários por ordem alfabética
        System.out.println("Lista de funcionários em ordem alfabética ");
        List<Funcionario> funcionariosOrdenados = new ArrayList<>(funcionarios);
        funcionariosOrdenados.sort(Comparator.comparing(Funcionario::getNome));
        imprimirFuncionarios(funcionariosOrdenados);

        // Imprimir total dos salários dos funcionários
        BigDecimal totalSalarios = funcionarios.stream()
                .map(Funcionario::getSalario)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        System.out.println("\nTotal dos salários: " + formatarValor(totalSalarios));

        // Imprimir quantos funcionários ganham acima do salário mínimo
        BigDecimal salarioMinimo = new BigDecimal("1212.00");
        System.out.println("\nQuantidade de salários mínimos que cada funcionário ganha:");
        funcionarios.forEach(f -> {
            BigDecimal salariosMinimos = f.getSalario().divide(salarioMinimo, 2, BigDecimal.ROUND_HALF_UP);
            System.out.println(f.getNome() + ": " + salariosMinimos + " salários mínimos");
        });
    
    }

    private static void imprimirFuncionarios(List<Funcionario> funcionarios) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.00");
        funcionarios.forEach(f -> {
            System.out.println("Nome: " + f.getNome() +
                    ", Data de Nascimento: " + f.getDataNascimento().format(formatter) +
                    ", Salário: " + decimalFormat.format(f.getSalario()) +
                    ", Função: " + f.getFuncao());
        });
    }

    private static String formatarValor(BigDecimal valor) {
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.00");
        return decimalFormat.format(valor);
    }
}
